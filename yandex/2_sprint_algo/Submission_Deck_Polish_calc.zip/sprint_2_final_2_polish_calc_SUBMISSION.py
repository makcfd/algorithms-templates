"""
ID of package:
89742090
"""


class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self):
        return self.items[-1]

    def size(self):
        return len(self.items)


def evaluate_expression(tokens):
    stack = Stack()
    for token in tokens:
        if token != "+" and token != "-" and token != "*" and token != "/":
            stack.push(int(token))
        else:
            b = stack.pop()
            a = stack.pop()
            if token == "+":
                stack.push(a + b)
            elif token == "-":
                stack.push(a - b)
            elif token == "*":
                stack.push(a * b)
            elif token == "/":
                stack.push(a // b)
    return stack.pop()


if __name__ == "__main__":
    operations = []
    numbers = []
    combinations = input().split(" ")
    print(evaluate_expression(combinations))
