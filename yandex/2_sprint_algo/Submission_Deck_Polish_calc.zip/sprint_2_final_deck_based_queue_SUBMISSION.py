"""
ID of package:
89765203
"""


def input():
    global test
    return test.pop(0)


DEBUG = False


def debug_mode(func):
    def wrapped(*args, **kwargs):
        result = func(*args, **kwargs)
        if DEBUG:
            print(deck.deck)
        return result
    return wrapped


class Deck:

    def __init__(self, n):
        self.deck = [None] * n
        self.max_n = n
        self.head = 0
        self.tail = 0
        self.size = 0

    def is_empty(self):
        return self.size == 0

    @debug_mode
    def push_front(self, x):
        "filling in from right to left towards the head"
        if self.size != self.max_n:
            self.head = (self.head - 1) % self.max_n
            self.deck[self.head] = x
            self.size += 1
        else:
            print("error")

    @debug_mode
    def push_back(self, x):
        "filling in from left to right towards the tail"
        if self.size != self.max_n:
            self.deck[self.tail] = x
            self.tail = (self.tail + 1) % self.max_n
            self.size += 1
        else:
            print("error")

    @debug_mode
    def pop_front(self):
        "classic pop for a queue"
        if self.is_empty():
            return "error"
        x = self.deck[self.head]
        self.deck[self.head] = None
        self.head = (self.head + 1) % self.max_n
        self.size -= 1
        return x

    @debug_mode
    def pop_back(self):
        "reverted pop from a queue"
        if self.is_empty():
            return "error"
        self.tail = (self.tail - 1) % self.max_n
        x = self.deck[self.tail]
        self.deck[self.tail] = None
        self.size -= 1
        return x

    def size(self):
        return self.size

    def __str__(self) -> str:
        return self.deck


if __name__ == "__main__":
    number = int(input())
    deck_size = int(input())
    deck = Deck(deck_size)
    for _ in range(number):
        command = input().split()
        if DEBUG:
            print(f"command is: {command}")
        if command[0] == "push_front":
            deck.push_front(command[1])
        elif command[0] == "push_back":
            deck.push_back(command[1])
        elif command[0] == "pop_back":
            print(deck.pop_back())
        elif command[0] == "pop_front":
            print(deck.pop_front())
        elif command[0] == "size":
            print(deck.size())
