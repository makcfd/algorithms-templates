"""
ID посылки: 89508253
"""

from typing import List


def get_nearest_zeros(street: List[int]) -> List[int]:
    n = len(street)
    result = [n] * n

    for i, v in enumerate(street):
        if v == 0:
            result[i] = 0
        else:
            result[i] = result[i - 1] + 1
# we start with n-2 because n-1 element, or last element
# in the array has no neighbor
# once we start with n-2 we proceed to next element to the left
    for i in range(n - 2, -1, -1):
        if street[i] != 0:
            result[i] = min(result[i], result[i + 1] + 1)
    return result


def read_input() -> List[int]:
    _ = input()
    return [int(i) for i in input().strip().split()]


if __name__ == '__main__':
    print(" ".join(map(str, get_nearest_zeros(read_input()))))
